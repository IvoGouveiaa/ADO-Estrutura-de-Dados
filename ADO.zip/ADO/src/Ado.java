package ADO;
import java.util.Scanner;
public class Ado {
    
public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    Vetor casas = new Vetor(4);
    casas.adiciona("LufaLufa");
    casas.adiciona("Grifinoria");
    casas.adiciona("Sonserina");
    casas.adiciona("Corvinal");

    Vetor pontos = new Vetor ( 4);
    Vetor Trimestre = new Vetor (4); 

    








}



}
